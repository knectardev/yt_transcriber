"""Build a two-staff MusicXML score from the quantized grid.

Notes that start and end together on the same staff become a chord. Notes
with independent durations stay in separate voices. The staff split is a
pitch threshold, not a contrapuntal analysis: a middle-voice crossing will
need a hand edit in MuseScore. That analysis is deliberately not guessed here.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from music21 import chord, clef, instrument, layout, meter, note, pitch, stream, tempo, tie

from baroque_transcribe.quantize import GridNote, Quantization


class NotationError(RuntimeError):
    pass


@dataclass
class GridEvent:
    onset: int
    offset: int
    pitches: list[int]
    velocity: int


def _collapse(notes: list[GridNote]) -> list[GridEvent]:
    grouped: dict[tuple[int, int], list[GridNote]] = {}
    for item in notes:
        grouped.setdefault((item.onset_step, item.offset_step), []).append(item)
    events = []
    for (onset, offset), members in grouped.items():
        members.sort(key=lambda item: item.pitch)
        velocity = int(round(sum(item.velocity for item in members) / len(members)))
        events.append(
            GridEvent(
                onset=onset,
                offset=offset,
                pitches=[item.pitch for item in members],
                velocity=velocity,
            )
        )
    events.sort(key=lambda item: (item.onset, max(item.pitches)))
    return events


def _pack_voices(events: list[GridEvent]) -> list[list[GridEvent]]:
    voices: list[list[GridEvent]] = []
    ends: list[int] = []
    for event in sorted(events, key=lambda item: (item.onset, -max(item.pitches))):
        placed = False
        for index, end in enumerate(ends):
            if event.onset >= end:
                voices[index].append(event)
                ends[index] = event.offset
                placed = True
                break
        if not placed:
            voices.append([event])
            ends.append(event.offset)
    return voices or [[]]


def _steps_to_ql(steps: int, subdivision: int) -> Fraction:
    return Fraction(steps * 4, subdivision)


def _tie(element: note.GeneralNote, kind: str) -> None:
    mark = tie.Tie(kind)
    if isinstance(element, chord.Chord):
        for inner in element.notes:
            inner.tie = tie.Tie(kind)
    else:
        element.tie = mark


def _midi_pitch(midi_note: int) -> pitch.Pitch:
    spelled = pitch.Pitch()
    spelled.midi = midi_note
    return spelled


def _general_note(pitches: list[int], quarter_length: Fraction, velocity: int) -> note.GeneralNote:
    if len(pitches) == 1:
        element: note.GeneralNote = note.Note(_midi_pitch(pitches[0]))
    else:
        element = chord.Chord([_midi_pitch(midi_note) for midi_note in pitches])
    element.quarterLength = quarter_length
    element.volume.velocity = velocity
    return element


def _render_voice(
    events: list[GridEvent],
    start: int,
    end: int,
    subdivision: int,
) -> list[note.GeneralNote]:
    active: list[tuple[GridEvent, int, int]] = []
    for event in events:
        if event.offset <= start or event.onset >= end:
            continue
        active.append((event, max(event.onset, start), min(event.offset, end)))
    active.sort(key=lambda item: item[1])
    rendered: list[note.GeneralNote] = []
    cursor = start
    for event, clip_start, clip_end in active:
        if clip_start > cursor:
            rest = note.Rest(quarterLength=_steps_to_ql(clip_start - cursor, subdivision))
            rendered.append(rest)
        element = _general_note(
            event.pitches,
            _steps_to_ql(clip_end - clip_start, subdivision),
            event.velocity,
        )
        if event.onset < start and event.offset > end:
            _tie(element, "continue")
        elif event.onset < start:
            _tie(element, "stop")
        elif event.offset > end:
            _tie(element, "start")
        rendered.append(element)
        cursor = clip_end
    if cursor < end:
        rendered.append(note.Rest(quarterLength=_steps_to_ql(end - cursor, subdivision)))
    return rendered


def _staff_events(events: list[GridEvent], staff_split: int, treble: bool) -> list[GridEvent]:
    selected: list[GridEvent] = []
    for event in events:
        pitches = [
            pitch
            for pitch in event.pitches
            if (pitch >= staff_split if treble else pitch < staff_split)
        ]
        if pitches:
            selected.append(
                GridEvent(event.onset, event.offset, pitches, event.velocity)
            )
    return selected


def _fill_part(
    part: stream.Part,
    events: list[GridEvent],
    quantization: Quantization,
    opening_clef: clef.Clef,
) -> None:
    per_measure = quantization.steps_per_measure
    first = -quantization.lead_steps
    last_note = max((event.offset for event in events), default=per_measure)
    last_bar = (max(last_note - 1, first) // per_measure) * per_measure
    if last_bar < first:
        last_bar = first
    voices = _pack_voices(events)
    signature = meter.TimeSignature(f"{quantization.numerator}/{quantization.denominator}")
    mark = tempo.MetronomeMark(number=quantization.bpm)
    measure_index = 0
    start = first
    while start <= last_bar:
        measure = stream.Measure(number=measure_index + 1)
        if measure_index == 0:
            measure.insert(0, opening_clef)
            measure.insert(0, signature)
            measure.insert(0, mark)
        voice_notes = [
            _render_voice(voice, start, start + per_measure, quantization.subdivision)
            for voice in voices
        ]
        if len(voice_notes) == 1:
            for element in voice_notes[0]:
                measure.append(element)
        else:
            for voice_id, elements in enumerate(voice_notes, start=1):
                voice = stream.Voice(id=str(voice_id))
                for element in elements:
                    voice.append(element)
                measure.insert(0, voice)
        part.append(measure)
        start += per_measure
        measure_index += 1


def write_musicxml(
    path: Path,
    quantization: Quantization,
    *,
    staff_split: int = 60,
    title: str = "Piano transcription",
) -> Path:
    events = _collapse(quantization.grid)
    from music21 import metadata

    score = stream.Score()
    score.metadata = metadata.Metadata()
    score.metadata.title = title
    score.metadata.movementName = (
        "Quantized for notation. Compare it with raw.mid before treating a note as certain."
    )
    score.insert(0, instrument.Piano())

    right = stream.Part(id="right-hand")
    left = stream.Part(id="left-hand")
    right.partName = "Piano"
    right.partAbbreviation = "Pno."
    left.partName = "Piano"
    left.partAbbreviation = "Pno."
    _fill_part(right, _staff_events(events, staff_split, True), quantization, clef.TrebleClef())
    _fill_part(left, _staff_events(events, staff_split, False), quantization, clef.BassClef())

    group = layout.StaffGroup([right, left], name="Piano", abbreviation="Pno.", symbol="brace", barTogether=True)
    score.insert(0, group)
    score.append(right)
    score.append(left)

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        written = score.write("musicxml", fp=str(path))
    except Exception as exc:  # music21 raises a variety of export errors
        raise NotationError(f"MusicXML export failed: {exc}") from exc
    written_path = Path(str(written)) if written else path
    if written_path != path and written_path.exists():
        written_path.replace(path)
    if not path.exists():
        raise NotationError(f"music21 did not write {path}.")
    return path
