"""Acquire a recording and make a working copy for the transcription model.

The file the user points at is never opened for writing. A YouTube download
is stored once, then a trimmed mono 16 kHz copy is peak-normalized for the
model. Times in the MIDI files are relative to that working copy.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import numpy as np
import soundfile as sf

from baroque_transcribe.defaults import MODEL_SAMPLE_RATE, WORKING_PEAK

LOCAL_EXTENSIONS = {".wav", ".mp3", ".flac"}


class AudioError(RuntimeError):
    pass


@dataclass
class PreparedAudio:
    source_wav: Path
    working_wav: Path
    sample_rate: int
    duration: float
    full_duration: float
    start: float
    end: float
    original_peak: float
    title: str
    origin: str


def parse_timestamp(value: str | float | int | None) -> float | None:
    """Accept seconds, ``M:SS``, or ``H:MM:SS``. Empty means "not set"."""

    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        seconds = float(value)
    else:
        text = str(value).strip()
        if text == "" or text.lower() in {"none", "start", "end"}:
            return None
        parts = text.split(":")
        try:
            if len(parts) == 1:
                seconds = float(parts[0])
            elif len(parts) == 2:
                seconds = int(parts[0]) * 60 + float(parts[1])
            elif len(parts) == 3:
                seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
            else:
                raise ValueError
        except ValueError as exc:
            raise AudioError(
                f"Could not read time {value!r}. Use seconds, M:SS, or H:MM:SS."
            ) from exc
    if seconds < 0:
        raise AudioError("Times cannot be negative.")
    return seconds


def is_url(source: str) -> bool:
    parsed = urlparse(source.strip())
    return parsed.scheme in {"http", "https"}


def slugify(text: str, fallback: str = "transcription") -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower()
    return slug[:80] or fallback


def require_ffmpeg() -> None:
    if shutil.which("ffmpeg") is None or shutil.which("ffprobe") is None:
        raise AudioError(
            "ffmpeg and ffprobe must be on PATH. "
            "On Windows, install FFmpeg and reopen the terminal. "
            "One option is: winget install Gyan.FFmpeg"
        )


def _run(command: list[str]) -> str:
    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise AudioError(f"Command failed: {' '.join(command)}\n{detail}") from exc
    return completed.stdout.strip()


def probe_duration(path: Path) -> float:
    raw = _run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ]
    )
    try:
        return float(raw)
    except ValueError as exc:
        raise AudioError(f"ffprobe did not return a duration for {path}.") from exc


def _ffmpeg_wav(
    source: Path,
    dest: Path,
    *,
    start: float | None = None,
    end: float | None = None,
    sample_rate: int | None = None,
    mono: bool = False,
) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    command = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"]
    if start is not None and start > 0:
        command += ["-ss", f"{start:.6f}"]
    command += ["-i", str(source)]
    if end is not None:
        duration = end - (start or 0.0)
        if duration <= 0:
            raise AudioError("The end time must be later than the start time.")
        command += ["-t", f"{duration:.6f}"]
    command.append("-vn")
    if mono:
        command += ["-ac", "1"]
    if sample_rate is not None:
        command += ["-ar", str(sample_rate)]
    command += ["-c:a", "pcm_s16le", str(dest)]
    _run(command)


# yt-dlp only enables Deno unless told otherwise. Node is the runtime most
# Windows machines already have, and YouTube extraction now expects one.
JS_RUNTIMES = ("deno", "node", "bun")
# Tried, in order, when YouTube asks for a sign-in and the user did not name a browser.
BROWSER_COOKIE_SOURCES = ("chrome", "edge", "firefox", "brave", "chromium")


def _yt_dlp(*arguments: str) -> str:
    return _run([sys.executable, "-m", "yt_dlp", *_js_runtime_args(), *arguments])


def _js_runtime_args() -> list[str]:
    for runtime in JS_RUNTIMES:
        found = shutil.which(runtime)
        if found:
            return ["--js-runtimes", f"{runtime}:{found}"]
    return []


def _youtube_auth_args(cookies: Path | None, cookies_from_browser: str | None) -> list[str]:
    arguments: list[str] = []
    if cookies is not None:
        arguments += ["--cookies", str(cookies)]
    if cookies_from_browser:
        arguments += ["--cookies-from-browser", cookies_from_browser]
    return arguments


def _youtube_sign_in_required(message: str) -> bool:
    text = message.lower()
    return "sign in" in text or "not a bot" in text or "confirm you" in text


def _missing_browser_cookies(message: str) -> bool:
    text = message.lower()
    return "could not find" in text and "cookie" in text


def _youtube_title(
    url: str,
    *,
    cookies: Path | None = None,
    cookies_from_browser: str | None = None,
) -> str:
    try:
        title = _yt_dlp(
            "--no-download",
            "--no-playlist",
            *_youtube_auth_args(cookies, cookies_from_browser),
            "--print",
            "title",
            url,
        )
    except AudioError:
        title = ""
    return title.splitlines()[0].strip() if title else ""


def download_youtube(
    url: str,
    dest: Path,
    *,
    cookies: Path | None = None,
    cookies_from_browser: str | None = None,
) -> str:
    """Download the best available audio and decode it to PCM WAV.

    A signed-in YouTube page in your browser is not visible to a different
    computer. When YouTube asks for a sign-in, this retries the browsers on
    *this* machine. A login on another PC has to be used by running the
    command there.
    """

    require_ffmpeg()
    dest.parent.mkdir(parents=True, exist_ok=True)
    attempts: list[str | None] = [cookies_from_browser]
    if cookies is None and cookies_from_browser is None:
        attempts = [None, *BROWSER_COOKIE_SOURCES]

    sign_in_error: AudioError | None = None
    for browser in attempts:
        try:
            return _download_youtube_once(
                url,
                dest,
                cookies=cookies,
                cookies_from_browser=browser,
            )
        except AudioError as exc:
            message = str(exc)
            if "locked" in message.lower():
                raise AudioError(
                    message
                    + "\nThe browser cookie database is locked. Close that browser and run the command again."
                ) from exc
            if browser is None and _youtube_sign_in_required(message):
                sign_in_error = exc
                continue
            if browser is not None and _missing_browser_cookies(message):
                continue
            if browser is not None and cookies_from_browser is None and _youtube_sign_in_required(message):
                sign_in_error = exc
                continue
            raise
    if sign_in_error is None:
        raise AudioError("YouTube download failed before a browser cookie could be tried.")
    raise AudioError(
        "YouTube asked for a sign-in, and this computer has no readable Chrome, Edge, "
        "Firefox, Brave, or Chromium cookie database. A login in a browser on another "
        "computer is not available here. On the PC where you are signed in to YouTube, run:\n"
        f'  baroque-transcribe transcribe "{url}" -o transcriptions/baroque_improvisation '
        "--cookies-from-browser chrome"
    ) from sign_in_error


def _download_youtube_once(
    url: str,
    dest: Path,
    *,
    cookies: Path | None,
    cookies_from_browser: str | None,
) -> str:
    if cookies_from_browser:
        print(f"Trying YouTube download with {cookies_from_browser} cookies.")
    title = _youtube_title(url, cookies=cookies, cookies_from_browser=cookies_from_browser)
    template = dest.with_suffix("")
    # yt-dlp appends the extension from the template. A fixed wav name keeps
    # the decoded file where the rest of the pipeline expects it.
    output = str(template) + ".%(ext)s"
    if dest.exists():
        dest.unlink()
    _yt_dlp(
        "--no-playlist",
        *_youtube_auth_args(cookies, cookies_from_browser),
        "-f",
        "bestaudio/best",
        "-x",
        "--audio-format",
        "wav",
        "--audio-quality",
        "0",
        "--no-progress",
        "-o",
        output,
        url,
    )
    if not dest.exists():
        produced = list(dest.parent.glob(template.name + ".*"))
        wavs = [path for path in produced if path.suffix.lower() == ".wav"]
        if len(wavs) == 1:
            wavs[0].replace(dest)
        else:
            raise AudioError(
                "yt-dlp finished without writing a WAV file. "
                "The video may be unavailable, age-restricted, or blocked."
            )
    return title or dest.stem


def peak_normalize(path: Path, peak: float = WORKING_PEAK) -> float:
    """Scale a WAV so its peak sample is ``peak``. Returns the peak before scaling."""

    audio, sample_rate = sf.read(path, always_2d=False)
    array = np.asarray(audio, dtype=np.float64)
    original = float(np.max(np.abs(array))) if array.size else 0.0
    if original < 1e-8:
        raise AudioError(
            "The working audio is silent, so there is nothing to transcribe. "
            "Check the start and end times."
        )
    scaled = array * (peak / original)
    sf.write(path, scaled, sample_rate, subtype="PCM_16")
    return original


def load_working_audio(path: Path) -> tuple[np.ndarray, int]:
    audio, sample_rate = sf.read(path, always_2d=False)
    array = np.asarray(audio, dtype=np.float32)
    if array.ndim != 1:
        array = array.mean(axis=1).astype(np.float32)
    return array, int(sample_rate)


def prepare_audio(
    source: str,
    output_dir: Path,
    *,
    start: float | None = None,
    end: float | None = None,
    cookies: Path | None = None,
    cookies_from_browser: str | None = None,
) -> PreparedAudio:
    """Copy or download ``source`` and write ``source.wav`` plus ``working.wav``."""

    require_ffmpeg()
    output_dir.mkdir(parents=True, exist_ok=True)
    source_wav = output_dir / "source.wav"
    working_wav = output_dir / "working.wav"
    origin = source

    if is_url(source):
        title = download_youtube(
            source,
            source_wav,
            cookies=cookies,
            cookies_from_browser=cookies_from_browser,
        )
    else:
        path = Path(source).expanduser().resolve()
        if not path.is_file():
            raise AudioError(f"Audio file not found: {path}")
        if path.suffix.lower() not in LOCAL_EXTENSIONS:
            allowed = ", ".join(sorted(LOCAL_EXTENSIONS))
            raise AudioError(f"Use a {allowed} file, or pass a YouTube URL. Got {path.suffix!r}.")
        title = path.stem
        _ffmpeg_wav(path, source_wav)
        origin = str(path)

    full_duration = probe_duration(source_wav)
    trim_start = 0.0 if start is None else start
    trim_end = full_duration if end is None else end
    if trim_start > full_duration:
        raise AudioError(
            f"Start time {trim_start:.2f}s is past the end of the audio ({full_duration:.2f}s)."
        )
    trim_end = min(trim_end, full_duration)
    if trim_end - trim_start < 0.2:
        raise AudioError("The selected region is shorter than 0.2 seconds.")

    _ffmpeg_wav(
        source_wav,
        working_wav,
        start=trim_start,
        end=trim_end,
        sample_rate=MODEL_SAMPLE_RATE,
        mono=True,
    )
    original_peak = peak_normalize(working_wav)
    working, sample_rate = load_working_audio(working_wav)
    if sample_rate != MODEL_SAMPLE_RATE:
        raise AudioError(f"Working audio is {sample_rate} Hz; the model expects {MODEL_SAMPLE_RATE} Hz.")
    duration = float(len(working) / sample_rate)
    return PreparedAudio(
        source_wav=source_wav,
        working_wav=working_wav,
        sample_rate=sample_rate,
        duration=duration,
        full_duration=full_duration,
        start=trim_start,
        end=trim_start + duration,
        original_peak=original_peak,
        title=title,
        origin=origin,
    )
