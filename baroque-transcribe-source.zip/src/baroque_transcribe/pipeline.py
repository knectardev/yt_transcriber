"""Join acquisition, transcription, MIDI, notation, and diagnostics."""

from __future__ import annotations

import json
import platform
from dataclasses import dataclass
from pathlib import Path

from baroque_transcribe import __version__
from baroque_transcribe.audio import PreparedAudio, load_working_audio, parse_timestamp, prepare_audio, slugify
from baroque_transcribe.defaults import (
    BASIC_PITCH_FRAME_THRESHOLD,
    BASIC_PITCH_MIN_NOTE_MS,
    BASIC_PITCH_ONSET_THRESHOLD,
    BYTEDANCE_FRAME_THRESHOLD,
    BYTEDANCE_OFFSET_THRESHOLD,
    BYTEDANCE_ONSET_THRESHOLD,
    BYTEDANCE_PEDAL_OFFSET_THRESHOLD,
    DEFAULT_STAFF_SPLIT,
    DEFAULT_SUBDIVISION,
    DEFAULT_TIME_SIGNATURE,
    DIAGNOSTICS_DIR,
    MANIFEST,
    NOTES_JSON,
    PEDAL_JSON,
    QUANTIZED_MID,
    RAW_MID,
    SCORE_XML,
    WORKING_WAV,
)
from baroque_transcribe.diagnostics import render_diagnostics
from baroque_transcribe.midi_export import write_quantized_midi, write_raw_midi
from baroque_transcribe.notation import write_musicxml
from baroque_transcribe.quantize import Quantization, parse_time_signature, quantize_notes
from baroque_transcribe.schema import Transcription, read_transcription, write_pedal_file
from baroque_transcribe.tempo import TempoEstimate, estimate_tempo
from baroque_transcribe.transcribe import transcribe_basic_pitch, transcribe_bytedance


@dataclass
class ProjectResult:
    output_dir: Path
    note_count: int
    pedal_count: int
    tempo_bpm: float | None
    time_signature: str
    warnings: list[str]


def _write_manifest(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _read_manifest(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_output_dir(source: str, output: Path | None, name: str | None) -> Path:
    if output is not None:
        return output
    if name:
        slug = slugify(name)
    else:
        slug = slugify(Path(source).stem if not source.startswith("http") else "transcription")
    return Path("transcriptions") / slug


def notate_transcription(
    transcription: Transcription,
    output_dir: Path,
    *,
    bpm: float,
    time_signature: tuple[int, int],
    subdivision: int,
    downbeat: float,
    staff_split: int,
    title: str,
    tempo_info: dict,
    time_signature_assumed: bool,
) -> Quantization:
    quantization = quantize_notes(
        transcription.notes,
        bpm=bpm,
        numerator=time_signature[0],
        denominator=time_signature[1],
        subdivision=subdivision,
        downbeat=downbeat,
    )
    write_raw_midi(output_dir / RAW_MID, transcription.notes, transcription.pedals)
    write_quantized_midi(output_dir / QUANTIZED_MID, quantization, staff_split)
    write_musicxml(
        output_dir / SCORE_XML,
        quantization,
        staff_split=staff_split,
        title=title,
    )
    manifest = _read_manifest(output_dir / MANIFEST)
    manifest.update(
        {
            "tempo": {
                "bpm": bpm,
                "downbeat_seconds": downbeat,
                "subdivision": subdivision,
                "time_signature": f"{time_signature[0]}/{time_signature[1]}",
                "time_signature_assumed": time_signature_assumed,
                **tempo_info,
            },
            "staff_split": staff_split,
            "notation": {
                "quantized_mid": QUANTIZED_MID,
                "score": SCORE_XML,
                "raw_mid": RAW_MID,
            },
        }
    )
    _write_manifest(output_dir / MANIFEST, manifest)
    return quantization


def run_transcription(
    source: str,
    output_dir: Path,
    *,
    start: str | float | None = None,
    end: str | float | None = None,
    model: str = "bytedance",
    device: str = "auto",
    checkpoint: Path | None = None,
    tempo: str | float | None = "auto",
    time_signature: str | None = None,
    subdivision: int = DEFAULT_SUBDIVISION,
    downbeat: str | float | None = 0.0,
    staff_split: int = DEFAULT_STAFF_SPLIT,
    onset_threshold: float | None = None,
    offset_threshold: float | None = None,
    frame_threshold: float | None = None,
    minimum_note_ms: float | None = None,
    diagnostics: bool = True,
    raw_only: bool = False,
    position: float | None = None,
    cookies: Path | None = None,
    cookies_from_browser: str | None = None,
) -> ProjectResult:
    start_seconds = parse_timestamp(start)
    end_seconds = parse_timestamp(end)
    downbeat_seconds = parse_timestamp(downbeat)
    if downbeat_seconds is None:
        downbeat_seconds = 0.0

    prepared = prepare_audio(
        source,
        output_dir,
        start=start_seconds,
        end=end_seconds,
        cookies=cookies,
        cookies_from_browser=cookies_from_browser,
    )
    audio, sample_rate = load_working_audio(prepared.working_wav)
    warnings: list[str] = []
    if prepared.full_duration - prepared.duration > 0.05:
        warnings.append(
            "MIDI times start at the beginning of working.wav, not the original file. "
            f"The excerpt begins at {prepared.start:.3f}s."
        )
    if prepared.duration > 20 * 60:
        warnings.append(
            "This excerpt is longer than 20 minutes. CPU transcription will take a while, "
            "and a long YouTube file often contains speech as well as piano."
        )

    model_name = model.lower().replace("_", "-")
    if model_name in {"bytedance", "piano", "kong"}:
        notes, pedals, resolved_device = transcribe_bytedance(
            audio,
            sample_rate,
            device=device,
            checkpoint=checkpoint,
            onset_threshold=BYTEDANCE_ONSET_THRESHOLD if onset_threshold is None else onset_threshold,
            offset_threshold=BYTEDANCE_OFFSET_THRESHOLD if offset_threshold is None else offset_threshold,
            frame_threshold=BYTEDANCE_FRAME_THRESHOLD if frame_threshold is None else frame_threshold,
        )
        model_id = "bytedance-note-pedal"
        thresholds = {
            "onset": BYTEDANCE_ONSET_THRESHOLD if onset_threshold is None else onset_threshold,
            "offset": BYTEDANCE_OFFSET_THRESHOLD if offset_threshold is None else offset_threshold,
            "frame": BYTEDANCE_FRAME_THRESHOLD if frame_threshold is None else frame_threshold,
            "pedal_offset": BYTEDANCE_PEDAL_OFFSET_THRESHOLD,
        }
    elif model_name in {"basic-pitch", "basicpitch", "basic_pitch"}:
        notes, pedals = transcribe_basic_pitch(
            prepared.working_wav,
            onset_threshold=BASIC_PITCH_ONSET_THRESHOLD if onset_threshold is None else onset_threshold,
            frame_threshold=BASIC_PITCH_FRAME_THRESHOLD if frame_threshold is None else frame_threshold,
            minimum_note_ms=BASIC_PITCH_MIN_NOTE_MS if minimum_note_ms is None else minimum_note_ms,
        )
        resolved_device = "onnxruntime"
        model_id = "basic-pitch"
        thresholds = {
            "onset": BASIC_PITCH_ONSET_THRESHOLD if onset_threshold is None else onset_threshold,
            "frame": BASIC_PITCH_FRAME_THRESHOLD if frame_threshold is None else frame_threshold,
            "minimum_note_ms": BASIC_PITCH_MIN_NOTE_MS if minimum_note_ms is None else minimum_note_ms,
            "melodia_trick": False,
        }
        warnings.append(
            "Basic Pitch does not detect the sustain pedal and is less reliable "
            "than the ByteDance piano model on dense counterpoint."
        )
    else:
        raise ValueError("Model must be 'bytedance' or 'basic-pitch'.")

    if not notes:
        warnings.append(
            "The model returned no notes. The excerpt may be speech, silence, "
            "or a timbre the model does not recognize. No notes were added to fill the gap."
        )

    transcription = Transcription(notes=notes, pedals=pedals, model=model_id, source=prepared.origin)
    transcription.write(output_dir / NOTES_JSON)
    write_pedal_file(output_dir / PEDAL_JSON, pedals, model_id)
    write_raw_midi(output_dir / RAW_MID, notes, pedals)

    tempo_estimate = estimate_tempo(audio, sample_rate)
    chosen_bpm, tempo_assumed = _choose_tempo(tempo, tempo_estimate, warnings)
    if time_signature:
        signature = parse_time_signature(time_signature)
        signature_assumed = False
    else:
        signature = DEFAULT_TIME_SIGNATURE
        signature_assumed = True
        warnings.append(
            "No time signature was given. The score uses 4/4 as a placeholder. "
            "Re-run quantize with --time-signature once you know the meter."
        )

    manifest = {
        "program": f"baroque-transcribe {__version__}",
        "python": platform.python_version(),
        "system": platform.platform(),
        "origin": prepared.origin,
        "title": prepared.title,
        "model": model_id,
        "device": resolved_device,
        "thresholds": thresholds,
        "audio": {
            "source": "source.wav",
            "working": WORKING_WAV,
            "sample_rate": prepared.sample_rate,
            "full_duration_seconds": round(prepared.full_duration, 4),
            "excerpt_start_seconds": round(prepared.start, 4),
            "excerpt_end_seconds": round(prepared.end, 4),
            "working_duration_seconds": round(prepared.duration, 4),
            "peak_before_normalize": prepared.original_peak,
        },
        "counts": {"notes": len(notes), "pedals": len(pedals)},
        "tempo_estimate": tempo_estimate.to_dict(),
        "warnings": warnings,
        "accuracy": (
            "This is a model decoding of the recording, not a verified note-for-note "
            "transcription. Ornamentation, repeated notes, and notes hidden by the pedal "
            "are the usual failure points. Listen to diagnostics/comparison.wav and edit notes.json."
        ),
    }
    _write_manifest(output_dir / MANIFEST, manifest)

    if not raw_only:
        if chosen_bpm is None:
            warnings.append("Tempo could not be estimated. Notation was skipped. Pass --tempo.")
            manifest["warnings"] = warnings
            _write_manifest(output_dir / MANIFEST, manifest)
        else:
            notate_transcription(
                transcription,
                output_dir,
                bpm=chosen_bpm,
                time_signature=signature,
                subdivision=subdivision,
                downbeat=downbeat_seconds,
                staff_split=staff_split,
                title=prepared.title,
                tempo_info={
                    "source": "manual" if tempo not in (None, "auto") else "estimated",
                    "estimate": tempo_estimate.to_dict(),
                    "assumed_bpm": tempo_assumed,
                },
                time_signature_assumed=signature_assumed,
            )
            manifest = _read_manifest(output_dir / MANIFEST)
            manifest["warnings"] = warnings
            _write_manifest(output_dir / MANIFEST, manifest)

    if diagnostics:
        render_diagnostics(
            prepared.working_wav,
            notes,
            output_dir / DIAGNOSTICS_DIR,
            position=position,
        )

    print(f"Notes: {len(notes)}")
    print(f"Pedal events: {len(pedals)}")
    print(f"Output: {output_dir}")
    print(f"Review in the browser with: baroque-transcribe ui --project {output_dir}")
    for warning in warnings:
        print(f"warning: {warning}")
    return ProjectResult(
        output_dir=output_dir,
        note_count=len(notes),
        pedal_count=len(pedals),
        tempo_bpm=chosen_bpm,
        time_signature=f"{signature[0]}/{signature[1]}",
        warnings=warnings,
    )


def requantize_project(
    output_dir: Path,
    *,
    tempo: str | float | None = None,
    time_signature: str | None = None,
    subdivision: int = DEFAULT_SUBDIVISION,
    downbeat: str | float | None = None,
    staff_split: int | None = None,
    diagnostics: bool = True,
) -> ProjectResult:
    notes_path = output_dir / NOTES_JSON
    if not notes_path.exists():
        raise FileNotFoundError(f"No {NOTES_JSON} in {output_dir}. Transcribe the audio first.")
    transcription = read_transcription(notes_path)
    manifest = _read_manifest(output_dir / MANIFEST)
    previous = manifest.get("tempo") or {}
    warnings = list(manifest.get("warnings") or [])

    if tempo in (None, "auto"):
        if previous.get("bpm"):
            bpm = float(previous["bpm"])
            assumed = bool(previous.get("assumed_bpm"))
        else:
            working = output_dir / WORKING_WAV
            if not working.exists():
                raise FileNotFoundError("Pass --tempo. There is no previous tempo and no working.wav to estimate from.")
            audio, sample_rate = load_working_audio(working)
            estimate = estimate_tempo(audio, sample_rate)
            bpm, assumed = _choose_tempo("auto", estimate, warnings)
            if bpm is None:
                raise ValueError("Tempo could not be estimated. Pass --tempo with a BPM.")
    else:
        bpm = float(tempo)
        assumed = False

    if time_signature:
        signature = parse_time_signature(time_signature)
        assumed_meter = False
    elif previous.get("time_signature"):
        signature = parse_time_signature(str(previous["time_signature"]))
        assumed_meter = bool(previous.get("time_signature_assumed"))
    else:
        signature = DEFAULT_TIME_SIGNATURE
        assumed_meter = True

    if downbeat is None:
        downbeat_seconds = float(previous.get("downbeat_seconds") or 0.0)
    else:
        parsed = parse_timestamp(downbeat)
        downbeat_seconds = 0.0 if parsed is None else parsed
    split = DEFAULT_STAFF_SPLIT if staff_split is None else staff_split
    title = str(manifest.get("title") or output_dir.name)

    write_raw_midi(output_dir / RAW_MID, transcription.notes, transcription.pedals)
    write_pedal_file(output_dir / PEDAL_JSON, transcription.pedals, transcription.model)
    notate_transcription(
        transcription,
        output_dir,
        bpm=bpm,
        time_signature=signature,
        subdivision=subdivision,
        downbeat=downbeat_seconds,
        staff_split=split,
        title=title,
        tempo_info={"source": "manual" if tempo not in (None, "auto") else "previous-or-estimated", "assumed_bpm": assumed},
        time_signature_assumed=assumed_meter,
    )
    if diagnostics and (output_dir / WORKING_WAV).exists():
        render_diagnostics(output_dir / WORKING_WAV, transcription.notes, output_dir / DIAGNOSTICS_DIR)
    print(f"Rewrote MIDI and MusicXML for {len(transcription.notes)} notes in {output_dir}")
    return ProjectResult(
        output_dir=output_dir,
        note_count=len(transcription.notes),
        pedal_count=len(transcription.pedals),
        tempo_bpm=bpm,
        time_signature=f"{signature[0]}/{signature[1]}",
        warnings=warnings,
    )


def _choose_tempo(
    requested: str | float | None,
    estimate: TempoEstimate,
    warnings: list[str],
) -> tuple[float | None, bool]:
    if requested not in (None, "auto"):
        bpm = float(requested)
        if bpm <= 0:
            raise ValueError("Tempo must be a positive BPM, or 'auto'.")
        return bpm, False
    if estimate.bpm is None:
        warnings.append("Tempo estimation failed.")
        return None, True
    warnings.append(
        f"Tempo estimated at {estimate.bpm:.2f} BPM ({estimate.method}). "
        f"Also consider {estimate.candidates}. Rubato will not survive a single tempo."
    )
    return float(estimate.bpm), True


def prepare_only(
    source: str,
    output_dir: Path,
    start,
    end,
    *,
    cookies: Path | None = None,
    cookies_from_browser: str | None = None,
) -> PreparedAudio:
    prepared = prepare_audio(
        source,
        output_dir,
        start=parse_timestamp(start),
        end=parse_timestamp(end),
        cookies=cookies,
        cookies_from_browser=cookies_from_browser,
    )
    manifest = {
        "program": f"baroque-transcribe {__version__}",
        "origin": prepared.origin,
        "title": prepared.title,
        "audio": {
            "source": "source.wav",
            "working": WORKING_WAV,
            "sample_rate": prepared.sample_rate,
            "full_duration_seconds": round(prepared.full_duration, 4),
            "excerpt_start_seconds": round(prepared.start, 4),
            "excerpt_end_seconds": round(prepared.end, 4),
            "working_duration_seconds": round(prepared.duration, 4),
            "peak_before_normalize": prepared.original_peak,
        },
        "warnings": [
            "Audio has been prepared. No transcription has been run yet."
        ],
    }
    _write_manifest(output_dir / MANIFEST, manifest)
    print(f"Prepared {prepared.duration:.2f}s of audio in {output_dir}")
    return prepared
