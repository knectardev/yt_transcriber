"""Local review window for checking and correcting a transcription.

Run with ``baroque-transcribe ui``. Transcription still happens on this machine.
The table writes ``notes.json`` and rebuilds the MIDI and MusicXML from it.
"""

from __future__ import annotations

import os
from pathlib import Path

import pandas as pd

from baroque_transcribe.defaults import (
    DIAGNOSTICS_DIR,
    MANIFEST,
    NOTES_JSON,
    QUANTIZED_MID,
    RAW_MID,
    SCORE_XML,
    WORKING_WAV,
)
from baroque_transcribe.pipeline import requantize_project, run_transcription
from baroque_transcribe.schema import NoteEvent, PedalEvent, Transcription, read_transcription


def run() -> None:
    import json

    import streamlit as st

    st.set_page_config(page_title="Piano transcription", layout="wide")
    st.title("Piano transcription")
    st.write(
        "Transcribe a solo piano recording on this computer. "
        "The raw MIDI keeps the timing of the performance. "
        "The MusicXML score is a separate rhythmic reading for MuseScore."
    )

    default_project = os.environ.get("BAROQUE_UI_PROJECT", "transcriptions/performance")
    with st.sidebar:
        st.header("Source")
        source_kind = st.radio("Input", ["YouTube URL", "Local path", "Upload"], index=0)
        youtube = ""
        local_path = ""
        upload = None
        if source_kind == "YouTube URL":
            youtube = st.text_input("URL", placeholder="https://youtu.be/…")
        elif source_kind == "Local path":
            local_path = st.text_input("WAV, MP3, or FLAC path")
        else:
            upload = st.file_uploader("WAV, MP3, or FLAC", type=["wav", "mp3", "flac"])
        start = st.text_input("Start", value="0")
        end = st.text_input("End", value="", help="Leave empty to keep going until the file ends.")
        output = st.text_input("Output directory", value=default_project)
        model = st.selectbox("Model", ["bytedance", "basic-pitch"])
        device = st.selectbox("Device", ["auto", "cpu", "cuda"])
        tempo = st.text_input("Tempo", value="auto", help="BPM, or auto.")
        meter = st.text_input("Time signature", value="", help="Leave empty to assume 4/4.")
        subdivision = st.selectbox("Subdivision", [16, 8, 32], index=0)
        downbeat = st.text_input("Downbeat (seconds in the excerpt)", value="0")
        staff_split = st.number_input("Treble starts at MIDI pitch", min_value=21, max_value=108, value=60)
        run_clicked = st.button("Transcribe", type="primary")

    project = Path(output)
    if run_clicked:
        source = _resolve_source(source_kind, youtube, local_path, upload, project)
        if source is None:
            st.error("Choose a file or a URL first.")
        else:
            with st.spinner("Transcribing. A multi-minute recording on CPU can take several minutes."):
                try:
                    run_transcription(
                        source,
                        project,
                        start=start or None,
                        end=end or None,
                        model=model,
                        device=device,
                        tempo=tempo or "auto",
                        time_signature=meter or None,
                        subdivision=int(subdivision),
                        downbeat=downbeat or "0",
                        staff_split=int(staff_split),
                    )
                except Exception as exc:
                    st.exception(exc)
                else:
                    st.success(f"Wrote {project}")

    if not (project / NOTES_JSON).exists():
        st.info("Run a transcription, or point the output directory at an existing project.")
        return

    _show_project(project, int(subdivision), int(staff_split))


def _blank(value: object) -> bool:
    if value is None or value == "":
        return True
    try:
        return float(value) != float(value)  # NaN
    except (TypeError, ValueError):
        return False


def _resolve_source(kind: str, youtube: str, local_path: str, upload, project: Path) -> str | None:
    if kind == "YouTube URL":
        return youtube.strip() or None
    if kind == "Local path":
        return local_path.strip() or None
    if upload is None:
        return None
    inbox = project / "_uploads"
    inbox.mkdir(parents=True, exist_ok=True)
    dest = inbox / upload.name
    dest.write_bytes(upload.getbuffer())
    return str(dest)


def _show_project(project: Path, subdivision: int, staff_split: int) -> None:
    import json

    import streamlit as st

    transcription = read_transcription(project / NOTES_JSON)
    manifest = {}
    manifest_path = project / MANIFEST
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    counts = manifest.get("counts") or {}
    st.subheader(str(manifest.get("title") or project.name))
    st.write(
        f"{len(transcription.notes)} notes, {len(transcription.pedals)} pedal events. "
        f"Model: {transcription.model or 'unknown'}."
    )
    for warning in manifest.get("warnings") or []:
        st.warning(warning)
    accuracy = manifest.get("accuracy")
    if accuracy:
        st.caption(accuracy)

    diagnostics = project / DIAGNOSTICS_DIR
    overview = diagnostics / "overview.png"
    if overview.exists():
        st.image(str(overview), caption="Waveform, spectrogram, and detected notes")
    columns = st.columns(2)
    working = project / WORKING_WAV
    comparison = diagnostics / "comparison.wav"
    if working.exists():
        columns[0].audio(working.read_bytes(), format="audio/wav")
        columns[0].caption("Working audio (trimmed and normalized)")
    if comparison.exists():
        columns[1].audio(comparison.read_bytes(), format="audio/wav")
        columns[1].caption("Recording mixed with a tone rendering of the detected notes")

    downloads = st.columns(3)
    for column, filename, label in (
        (downloads[0], RAW_MID, "Raw MIDI"),
        (downloads[1], QUANTIZED_MID, "Quantized MIDI"),
        (downloads[2], SCORE_XML, "MusicXML"),
    ):
        path = project / filename
        if path.exists():
            column.download_button(label, path.read_bytes(), file_name=filename)

    st.subheader("Notes")
    st.caption("Edit a pitch, time, or velocity, then save. Times are seconds from the start of the working audio.")
    frame = pd.DataFrame(
        [
            {"pitch": note.pitch, "onset": note.onset, "offset": note.offset, "velocity": note.velocity}
            for note in transcription.notes
        ]
    )
    edited = st.data_editor(frame, num_rows="dynamic", width="stretch", key="notes")
    tempo = st.text_input("Tempo for the new score", value=str((manifest.get("tempo") or {}).get("bpm") or "auto"))
    meter = st.text_input(
        "Time signature for the new score",
        value=str((manifest.get("tempo") or {}).get("time_signature") or "4/4"),
    )
    if st.button("Save notes and rebuild MIDI / MusicXML"):
        notes = []
        for row in edited.to_dict(orient="records"):
            if any(_blank(row.get(key)) for key in ("pitch", "onset", "offset")):
                continue
            notes.append(
                NoteEvent(
                    pitch=int(row["pitch"]),
                    onset=float(row["onset"]),
                    offset=float(row["offset"]),
                    velocity=int(row.get("velocity") or 80),
                )
            )
        updated = Transcription(
            notes=notes,
            pedals=[PedalEvent(onset=item.onset, offset=item.offset) for item in transcription.pedals],
            model=transcription.model,
            source=transcription.source,
        )
        updated.write(project / NOTES_JSON)
        try:
            requantize_project(
                project,
                tempo=None if tempo in {"", "auto"} else tempo,
                time_signature=meter or None,
                subdivision=subdivision,
                staff_split=staff_split,
            )
        except Exception as exc:
            st.exception(exc)
        else:
            st.success("Rebuilt raw.mid, quantized.mid, and score.musicxml from the edited notes.")
            st.rerun()


if __name__ == "__main__":
    run()
