from pathlib import Path

import pretty_midi
from music21 import converter

from baroque_transcribe.midi_export import write_quantized_midi, write_raw_midi
from baroque_transcribe.notation import write_musicxml
from baroque_transcribe.quantize import quantize_notes
from baroque_transcribe.schema import NoteEvent, PedalEvent


def _performance() -> list[NoteEvent]:
    return [
        NoteEvent(60, 0.0, 0.5, 80),
        NoteEvent(64, 0.0, 0.5, 70),
        NoteEvent(67, 0.0, 1.0, 75),
        NoteEvent(62, 0.5, 1.0, 68),
        NoteEvent(48, 0.0, 2.0, 60),
    ]


def test_raw_midi_preserves_timing_and_pedal(tmp_path: Path):
    notes = [NoteEvent(61, 0.137, 0.58, 90)]
    pedals = [PedalEvent(0.05, 0.9)]
    path = tmp_path / "raw.mid"
    write_raw_midi(path, notes, pedals)
    midi = pretty_midi.PrettyMIDI(str(path))
    assert len(midi.instruments) == 1
    note = midi.instruments[0].notes[0]
    assert note.pitch == 61
    assert note.start == pytest_approx(0.137)
    assert note.end == pytest_approx(0.58)
    assert note.velocity == 90
    controls = [change for change in midi.instruments[0].control_changes if change.number == 64]
    assert [change.value for change in controls] == [127, 0]
    assert midi.get_tempo_changes()[1][0] == pytest_approx(120)


def test_quantized_midi_and_musicxml_keep_the_same_pitches(tmp_path: Path):
    quantization = quantize_notes(
        _performance(),
        bpm=120,
        numerator=4,
        denominator=4,
        subdivision=16,
        downbeat=0.0,
    )
    midi_path = tmp_path / "quantized.mid"
    score_path = tmp_path / "score.musicxml"
    write_quantized_midi(midi_path, quantization, staff_split=60)
    write_musicxml(score_path, quantization, staff_split=60, title="Test")

    midi = pretty_midi.PrettyMIDI(str(midi_path))
    assert midi.time_signature_changes[0].numerator == 4
    midi_pitches = sorted(note.pitch for instrument in midi.instruments for note in instrument.notes)
    assert midi_pitches == [48, 60, 62, 64, 67]
    right = midi.instruments[0].notes
    left = midi.instruments[1].notes
    assert {note.pitch for note in left} == {48}
    assert 60 in {note.pitch for note in right}

    score = converter.parse(str(score_path))
    found = []
    for element in score.recurse().notes:
        if element.isChord:
            found.extend(inner.pitch.midi for inner in element.notes)
        else:
            found.append(element.pitch.midi)
    assert sorted(set(found)) == [48, 60, 62, 64, 67]
    parts = list(score.parts)
    assert len(parts) == 2
    assert len(parts[0].getElementsByClass("Measure")) == 1


def pytest_approx(value: float):
    import pytest

    return pytest.approx(value, abs=0.01)
